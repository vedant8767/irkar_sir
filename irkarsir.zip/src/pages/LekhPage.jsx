import LekhStructure from "../components/Lekh/LekhStructure";

export default function LekhPage (){
    return(
        <div>
          <LekhStructure/>  
        </div>
    )
}