export default function RecentActivityPage (){
    return(
        <div>
            <h1>RecentActivityPage</h1>
        </div>
    )
}