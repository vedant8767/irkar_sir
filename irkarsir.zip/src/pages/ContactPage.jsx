import '../css/ContactPage.css'

export default function ContactPage (){
    return(
        <div className="contact_container">
            <div className="contact_left">
                <h1>Contact Me Now</h1>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. 
                    Voluptatem dicta ex quaerat voluptate mollitia eveniet praesentium,
                     nemo quae sequi, officiis ipsam? Reiciendis ad
                     consectetur corporis corrupti quam blanditiis consequuntur deserunt!
                </p><br />
                <h1>Address</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, autem?</p><br />
                <h1>Phone Number & Email</h1>
                <span>+91 8767476236</span><br />
                <span>ved123@gmail.com</span>
            </div>
            <div className="contact_right">
                <h1>Send Me a Message</h1>
                <form action="">
                    <input type="text" placeholder="Name" />
                    <input type="text" placeholder="Email" />
                    <input type="text" placeholder="Message" />
                    <button>send</button>
                </form>
            </div>
        </div>
    )
}