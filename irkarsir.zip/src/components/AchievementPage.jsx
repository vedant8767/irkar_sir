import '../css/AchievementPage.css'

export default function AchievementPage(){

    function gotoyt(videoId){
        window.location.href = `https://www.youtube.com/watch?v=${videoId}`;
    }
    return(
        <div className='achievement'>
        <h1>Recent Activities</h1>
        <div className='achievement_container'>
            <div className="main_card">
                <img src={`https://img.youtube.com/vi/1TpvtbUEBGA/maxresdefault.jpg`} alt="yt" onClick={()=>gotoyt('1TpvtbUEBGA')}/>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias ipsam tempora ex ad molestiae accusantium excepturi odit ullam nesciunt impedit.</p>
            </div>
            <div className="subcards">
                <div className="eachcardachev">
                <img src={`https://img.youtube.com/vi/vgjdaSf62ak/maxresdefault.jpg`} alt="yt" onClick={()=>gotoyt('vgjdaSf62ak')}/>
                    <p>Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Adipisci velit ab
                         eaque recusandae reprehenderit est voluptatum quod, culpa debitis eius.</p>
                </div>
                <div className="eachcardachev">
                <img src={`https://img.youtube.com/vi/1TpvtbUEBGA/maxresdefault.jpg`} alt="yt" onClick={()=>gotoyt('1TpvtbUEBGA')}/>
                    <p>Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Adipisci velit ab
                         eaque recusandae reprehenderit est voluptatum quod, culpa debitis eius.</p>
                </div>
                <div className="eachcardachev">
                <img src={`https://img.youtube.com/vi/kp9MgdI5GFk/maxresdefault.jpg`} alt="yt" onClick={()=>gotoyt('kp9MgdI5GFk')}/>
                    <p>Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Adipisci velit ab
                         eaque recusandae reprehenderit est voluptatum quod, culpa debitis eius.</p>
                </div>
            </div>
        </div>
        </div>
    )
}